namespace MeCab {
#   define VERSION "0.996"
}
